chrome.runtime.onInstalled.addListener(() => {
  console.log("AI Accessibility Assistant installed.");
});
