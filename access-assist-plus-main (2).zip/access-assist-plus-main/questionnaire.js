// Questionnaire script for BetterWeb Extension
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('accessibility-form');
    const saveBtn = document.getElementById('save-preferences');
    const progressFill = document.getElementById('progress-fill');
    const checkboxes = form.querySelectorAll('input[type="checkbox"]');
    
    // Update progress bar based on selections
    function updateProgress() {
        const totalCheckboxes = checkboxes.length;
        const checkedCheckboxes = form.querySelectorAll('input[type="checkbox"]:checked').length;
        const progressPercentage = Math.min((checkedCheckboxes / totalCheckboxes) * 100, 100);
        progressFill.style.width = progressPercentage + '%';
    }
    
    // Add event listeners to all checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateProgress);
    });
    
    // Save preferences
    saveBtn.addEventListener('click', function() {
        const preferences = {
            visual: [],
            dyslexia: [],
            adhd: [],
            photosensitivity: [],
            neurocognitive: []
        };
        
        // Collect selected preferences by category
        const checkedBoxes = form.querySelectorAll('input[type="checkbox"]:checked');
        checkedBoxes.forEach(checkbox => {
            const category = checkbox.name;
            const value = checkbox.value;
            if (preferences[category]) {
                preferences[category].push(value);
            }
        });
        
        // Get all selected features in a flat array
        const allFeatures = [];
        Object.values(preferences).forEach(categoryFeatures => {
            allFeatures.push(...categoryFeatures);
        });
        
        try {
            // Update user data with preferences
            const userData = JSON.parse(localStorage.getItem('betterWebUser') || '{}');
            userData.preferences = preferences;
            userData.selectedFeatures = allFeatures;
            userData.onboardingCompleted = true;
            userData.preferencesUpdatedAt = new Date().toISOString();
            
            localStorage.setItem('betterWebUser', JSON.stringify(userData));
            
            // Save preferences separately for easy access
            localStorage.setItem('betterWebPreferences', JSON.stringify(preferences));
            localStorage.setItem('betterWebSelectedFeatures', JSON.stringify(allFeatures));
            
            showSaveMessage('Preferences saved successfully! You can now use the extension.');
            
            // Close the window after a delay
            setTimeout(() => {
                window.close();
            }, 2000);
            
        } catch (error) {
            showSaveMessage('Failed to save preferences. Please try again.', true);
        }
    });
    
    // Load existing preferences if any
    loadExistingPreferences();
});

function showSaveMessage(message, isError = false) {
    const messageDiv = document.getElementById('save-message');
    messageDiv.textContent = message;
    messageDiv.className = isError ? 'error-message' : 'success-message';
    messageDiv.style.display = 'block';
}

function loadExistingPreferences() {
    try {
        const preferences = JSON.parse(localStorage.getItem('betterWebPreferences') || '{}');
        
        // Check boxes based on saved preferences
        Object.keys(preferences).forEach(category => {
            preferences[category].forEach(feature => {
                const checkbox = document.getElementById(feature);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        });
        
        // Update progress bar
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        const checkedCheckboxes = document.querySelectorAll('input[type="checkbox"]:checked').length;
        const progressPercentage = Math.min((checkedCheckboxes / checkboxes.length) * 100, 100);
        document.getElementById('progress-fill').style.width = progressPercentage + '%';
        
    } catch (error) {
        // Continue with empty form
    }
}