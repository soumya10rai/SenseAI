// Content script for BetterWeb Extension
(function() {
    'use strict';
    
    class BetterWebAccessibility {
        constructor() {
            this.activeFeatures = new Set();
            this.setupMessageListener();
            this.loadActiveFeatures();
            this.applyActiveFeatures();
        }
        
        setupMessageListener() {
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                switch (message.type) {
                    case 'ACTIVATE_FEATURE':
                        this.activateFeature(message.feature);
                        break;
                    case 'DEACTIVATE_FEATURE':
                        this.deactivateFeature(message.feature);
                        break;
                    case 'RESET_ALL_FEATURES':
                        this.resetAllFeatures();
                        break;
                }
                sendResponse({ success: true });
            });
        }
        
        loadActiveFeatures() {
            try {
                const activeFeatures = JSON.parse(localStorage.getItem('betterWebActiveFeatures') || '[]');
                this.activeFeatures = new Set(activeFeatures);
            } catch (error) {
                console.error('Error loading active features:', error);
            }
        }
        
        applyActiveFeatures() {
            this.activeFeatures.forEach(feature => {
                this.activateFeature(feature);
            });
        }
        
        activateFeature(featureId) {
            this.activeFeatures.add(featureId);
            this.updateLocalStorage();
            
            switch (featureId) {
                case 'increase-font-size':
                    this.increaseFontSize();
                    break;
                case 'increase-contrast':
                    this.increaseContrast();
                    break;
                case 'dark-mode':
                    this.enableDarkMode();
                    break;
                case 'zoom-tool':
                    this.enableZoom();
                    break;
                case 'cursor-enhancer':
                    this.enhanceCursor();
                    break;
                case 'dyslexic-font':
                    this.enableDyslexicFont();
                    break;
                case 'letter-spacing':
                    this.adjustLetterSpacing();
                    break;
                case 'line-spacing':
                    this.adjustLineSpacing();
                    break;
                case 'reading-ruler':
                    this.enableReadingRuler();
                    break;
                case 'background-tint':
                    this.enableBackgroundTint();
                    break;
                case 'minimal-ui':
                    this.enableMinimalUI();
                    break;
                case 'hide-distractions':
                    this.hideDistractions();
                    break;
                case 'reduce-animation':
                case 'fewer-animations':
                    this.reduceAnimations();
                    break;
                case 'reduce-bright-colors':
                    this.reduceBrightColors();
                    break;
                case 'block-flash':
                    this.blockFlashAnimations();
                    break;
                case 'reduce-brightness':
                    this.reduceBrightness();
                    break;
                case 'soft-contrast':
                    this.enableSoftContrast();
                    break;
                case 'high-structure':
                    this.enableHighStructure();
                    break;
                case 'line-highlighting':
                    this.enableLineHighlighting();
                    break;
                case 'text-magnifier':
                    this.enableTextMagnifier();
                    break;
                case 'larger-fonts':
                    this.enableLargerFonts();
                    break;
                case 'colorblind-mode':
                    this.enableColorblindMode();
                    break;
                default:
                    console.log('Feature not implemented:', featureId);
            }
        }
        
        deactivateFeature(featureId) {
            this.activeFeatures.delete(featureId);
            this.updateLocalStorage();
            
            // Remove feature-specific classes and styles
            document.body.classList.remove(`bw-${featureId}`);
            
            // Remove specific stylesheets
            const stylesheet = document.getElementById(`bw-style-${featureId}`);
            if (stylesheet) {
                stylesheet.remove();
            }
            
            // Special deactivation logic for certain features
            switch (featureId) {
                case 'reading-ruler':
                    this.removeReadingRuler();
                    break;
                case 'text-magnifier':
                    this.removeTextMagnifier();
                    break;
                case 'zoom-tool':
                    this.resetZoom();
                    break;
            }
        }
        
        resetAllFeatures() {
            this.activeFeatures.forEach(feature => {
                this.deactivateFeature(feature);
            });
            this.activeFeatures.clear();
            this.updateLocalStorage();
            
            // Remove all BetterWeb classes and styles
            document.body.className = document.body.className.replace(/bw-[\\w-]+/g, '');
            const stylesheets = document.querySelectorAll('[id^="bw-style-"]');
            stylesheets.forEach(sheet => sheet.remove());
        }
        
        updateLocalStorage() {
            try {
                localStorage.setItem('betterWebActiveFeatures', JSON.stringify([...this.activeFeatures]));
            } catch (error) {
                console.error('Error updating localStorage:', error);
            }
        }
        
        addStyles(featureId, css) {
            // Remove existing stylesheet for this feature
            const existingStyle = document.getElementById(`bw-style-${featureId}`);
            if (existingStyle) {
                existingStyle.remove();
            }
            
            // Add new stylesheet
            const style = document.createElement('style');
            style.id = `bw-style-${featureId}`;
            style.textContent = css;
            document.head.appendChild(style);
        }
        
        // Feature implementations
        increaseFontSize() {
            document.body.classList.add('bw-increase-font-size');
            this.addStyles('increase-font-size', `
                .bw-increase-font-size * {
                    font-size: calc(1em * 1.2) !important;
                    line-height: calc(1.2 * 1.2) !important;
                }
            `);
        }
        
        increaseContrast() {
            document.body.classList.add('bw-increase-contrast');
            this.addStyles('increase-contrast', `
                .bw-increase-contrast {
                    filter: contrast(150%) !important;
                }
                .bw-increase-contrast * {
                    text-shadow: 0 0 1px currentColor !important;
                }
            `);
        }
        
        enableDarkMode() {
            document.body.classList.add('bw-dark-mode');
            this.addStyles('dark-mode', `
                .bw-dark-mode {
                    background-color: #1a1a1a !important;
                    color: #ffffff !important;
                    filter: invert(1) hue-rotate(180deg) !important;
                }
                .bw-dark-mode img,
                .bw-dark-mode video,
                .bw-dark-mode iframe,
                .bw-dark-mode svg {
                    filter: invert(1) hue-rotate(180deg) !important;
                }
            `);
        }
        
        enableZoom() {
            document.body.style.zoom = '1.25';
            document.body.classList.add('bw-zoom-tool');
        }
        
        resetZoom() {
            document.body.style.zoom = '';
        }
        
        enhanceCursor() {
            document.body.classList.add('bw-cursor-enhancer');
            this.addStyles('cursor-enhancer', `
                .bw-cursor-enhancer,
                .bw-cursor-enhancer * {
                    cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><circle cx="16" cy="16" r="10" fill="red" fill-opacity="0.8" stroke="black" stroke-width="2"/></svg>') 16 16, auto !important;
                }
                .bw-cursor-enhancer a,
                .bw-cursor-enhancer button,
                .bw-cursor-enhancer [role="button"] {
                    cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><circle cx="16" cy="16" r="10" fill="blue" fill-opacity="0.8" stroke="black" stroke-width="2"/></svg>') 16 16, pointer !important;
                }
            `);
        }
        
        enableDyslexicFont() {
            document.body.classList.add('bw-dyslexic-font');
            this.addStyles('dyslexic-font', `
                .bw-dyslexic-font * {
                    font-family: 'OpenDyslexic', 'Comic Sans MS', cursive !important;
                }
            `);
        }
        
        adjustLetterSpacing() {
            document.body.classList.add('bw-letter-spacing');
            this.addStyles('letter-spacing', `
                .bw-letter-spacing * {
                    letter-spacing: 0.12em !important;
                }
            `);
        }
        
        adjustLineSpacing() {
            document.body.classList.add('bw-line-spacing');
            this.addStyles('line-spacing', `
                .bw-line-spacing * {
                    line-height: 1.8 !important;
                }
            `);
        }
        
        enableReadingRuler() {
            document.body.classList.add('bw-reading-ruler');
            
            // Create reading ruler
            const ruler = document.createElement('div');
            ruler.id = 'bw-reading-ruler';
            ruler.style.cssText = `
                position: fixed;
                left: 0;
                right: 0;
                height: 3px;
                background: rgba(255, 0, 0, 0.7);
                z-index: 10000;
                pointer-events: none;
                top: 50%;
                transition: top 0.1s ease;
            `;
            document.body.appendChild(ruler);
            
            // Follow mouse
            document.addEventListener('mousemove', this.updateReadingRuler);
        }
        
        updateReadingRuler(e) {
            const ruler = document.getElementById('bw-reading-ruler');
            if (ruler) {
                ruler.style.top = e.clientY + 'px';
            }
        }
        
        removeReadingRuler() {
            const ruler = document.getElementById('bw-reading-ruler');
            if (ruler) {
                ruler.remove();
            }
            document.removeEventListener('mousemove', this.updateReadingRuler);
        }
        
        enableBackgroundTint() {
            document.body.classList.add('bw-background-tint');
            this.addStyles('background-tint', `
                .bw-background-tint {
                    background-color: #f5f5dc !important;
                }
                .bw-background-tint * {
                    background-color: rgba(245, 245, 220, 0.8) !important;
                }
            `);
        }
        
        enableMinimalUI() {
            document.body.classList.add('bw-minimal-ui');
            this.addStyles('minimal-ui', `
                .bw-minimal-ui nav,
                .bw-minimal-ui header,
                .bw-minimal-ui footer,
                .bw-minimal-ui aside,
                .bw-minimal-ui [role="banner"],
                .bw-minimal-ui [role="navigation"],
                .bw-minimal-ui [role="complementary"] {
                    opacity: 0.3 !important;
                    transition: opacity 0.3s ease !important;
                }
                .bw-minimal-ui nav:hover,
                .bw-minimal-ui header:hover,
                .bw-minimal-ui footer:hover,
                .bw-minimal-ui aside:hover,
                .bw-minimal-ui [role="banner"]:hover,
                .bw-minimal-ui [role="navigation"]:hover,
                .bw-minimal-ui [role="complementary"]:hover {
                    opacity: 1 !important;
                }
            `);
        }
        
        hideDistractions() {
            document.body.classList.add('bw-hide-distractions');
            this.addStyles('hide-distractions', `
                .bw-hide-distractions [class*="ad"],
                .bw-hide-distractions [id*="ad"],
                .bw-hide-distractions [class*="banner"],
                .bw-hide-distractions [class*="popup"],
                .bw-hide-distractions [class*="modal"],
                .bw-hide-distractions iframe[src*="doubleclick"],
                .bw-hide-distractions iframe[src*="googlesyndication"],
                .bw-hide-distractions img[src*="ad"],
                .bw-hide-distractions .advertisement {
                    display: none !important;
                }
            `);
        }
        
        reduceAnimations() {
            document.body.classList.add('bw-reduce-animation');
            this.addStyles('reduce-animation', `
                .bw-reduce-animation,
                .bw-reduce-animation * {
                    animation-duration: 0.01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.01ms !important;
                    animation-delay: 0ms !important;
                    transition-delay: 0ms !important;
                }
            `);
        }
        
        reduceBrightColors() {
            document.body.classList.add('bw-reduce-bright-colors');
            this.addStyles('reduce-bright-colors', `
                .bw-reduce-bright-colors {
                    filter: brightness(0.8) saturate(0.7) !important;
                }
            `);
        }
        
        blockFlashAnimations() {
            document.body.classList.add('bw-block-flash');
            this.addStyles('block-flash', `
                .bw-block-flash [class*="flash"],
                .bw-block-flash [class*="blink"],
                .bw-block-flash [class*="strobe"] {
                    animation: none !important;
                    opacity: 1 !important;
                }
            `);
        }
        
        reduceBrightness() {
            document.body.classList.add('bw-reduce-brightness');
            this.addStyles('reduce-brightness', `
                .bw-reduce-brightness {
                    filter: brightness(0.7) !important;
                }
            `);
        }
        
        enableSoftContrast() {
            document.body.classList.add('bw-soft-contrast');
            this.addStyles('soft-contrast', `
                .bw-soft-contrast {
                    filter: contrast(0.8) !important;
                }
                .bw-soft-contrast * {
                    color: #555 !important;
                    background-color: #f9f9f9 !important;
                }
            `);
        }
        
        enableHighStructure() {
            document.body.classList.add('bw-high-structure');
            this.addStyles('high-structure', `
                .bw-high-structure * {
                    border: 1px solid #ddd !important;
                    margin: 5px !important;
                    padding: 10px !important;
                }
                .bw-high-structure h1, .bw-high-structure h2, .bw-high-structure h3 {
                    border: 2px solid #000 !important;
                    background-color: #f0f0f0 !important;
                }
            `);
        }
        
        enableLineHighlighting() {
            document.body.classList.add('bw-line-highlighting');
            
            // Add mouseover highlighting
            document.addEventListener('mouseover', this.highlightLine);
            document.addEventListener('mouseout', this.removeLineHighlight);
        }
        
        highlightLine(e) {
            if (e.target.tagName === 'P' || e.target.tagName === 'LI' || e.target.tagName === 'DIV') {
                e.target.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';
            }
        }
        
        removeLineHighlight(e) {
            if (e.target.tagName === 'P' || e.target.tagName === 'LI' || e.target.tagName === 'DIV') {
                e.target.style.backgroundColor = '';
            }
        }
        
        enableTextMagnifier() {
            document.body.classList.add('bw-text-magnifier');
            
            // Create magnifier
            const magnifier = document.createElement('div');
            magnifier.id = 'bw-text-magnifier';
            magnifier.style.cssText = `
                position: fixed;
                width: 200px;
                height: 100px;
                background: white;
                border: 2px solid #333;
                border-radius: 10px;
                z-index: 10000;
                pointer-events: none;
                font-size: 24px;
                padding: 10px;
                display: none;
                box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            `;
            document.body.appendChild(magnifier);
            
            document.addEventListener('mousemove', this.updateTextMagnifier);
        }
        
        updateTextMagnifier(e) {
            const magnifier = document.getElementById('bw-text-magnifier');
            if (magnifier && e.target.textContent && e.target.textContent.trim()) {
                magnifier.style.display = 'block';
                magnifier.style.left = (e.clientX + 20) + 'px';
                magnifier.style.top = (e.clientY - 60) + 'px';
                magnifier.textContent = e.target.textContent.substring(0, 50) + '...';
            } else if (magnifier) {
                magnifier.style.display = 'none';
            }
        }
        
        removeTextMagnifier() {
            const magnifier = document.getElementById('bw-text-magnifier');
            if (magnifier) {
                magnifier.remove();
            }
            document.removeEventListener('mousemove', this.updateTextMagnifier);
        }
        
        enableLargerFonts() {
            document.body.classList.add('bw-larger-fonts');
            this.addStyles('larger-fonts', `
                .bw-larger-fonts * {
                    font-size: calc(1em * 1.5) !important;
                    line-height: calc(1.2 * 1.5) !important;
                }
            `);
        }
        
        enableColorblindMode() {
            document.body.classList.add('bw-colorblind-mode');
            this.addStyles('colorblind-mode', `
                .bw-colorblind-mode {
                    filter: 
                        contrast(1.2)
                        brightness(1.1)
                        saturate(1.3) !important;
                }
                .bw-colorblind-mode * {
                    border-color: #000 !important;
                    outline: 1px solid #000 !important;
                }
            `);
        }
    }
    
    // Initialize the accessibility features
    let betterWebAccessibility;
    
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            betterWebAccessibility = new BetterWebAccessibility();
        });
    } else {
        betterWebAccessibility = new BetterWebAccessibility();
    }
    
})();