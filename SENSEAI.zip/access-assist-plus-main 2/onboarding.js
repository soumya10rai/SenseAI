// Onboarding script for BetterWeb Extension
document.addEventListener('DOMContentLoaded', function() {
    const signupBtn = document.getElementById('signup-btn');
    const loginBtn = document.getElementById('login-btn');
    const loginLink = document.getElementById('login-link');
    const signupLink = document.getElementById('signup-link');
    const loginForm = document.getElementById('login-form');
    const existingLoginForm = document.getElementById('existing-login-form');
    
    // Switch between signup and login forms
    loginLink.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.style.display = 'none';
        existingLoginForm.style.display = 'block';
    });
    
    signupLink.addEventListener('click', function(e) {
        e.preventDefault();
        existingLoginForm.style.display = 'none';
        loginForm.style.display = 'block';
    });
    
    // Handle signup
    signupBtn.addEventListener('click', function() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const name = document.getElementById('name').value;
        
        if (!email || !password || !name) {
            showError('Please fill in all fields.');
            return;
        }
        
        if (!isValidEmail(email)) {
            showError('Please enter a valid email address.');
            return;
        }
        
        if (password.length < 6) {
            showError('Password must be at least 6 characters long.');
            return;
        }
        
        // Store user data
        const userData = {
            email: email,
            name: name,
            password: btoa(password), // Basic encoding (not for production)
            registeredAt: new Date().toISOString(),
            onboardingCompleted: false
        };
        
        try {
            localStorage.setItem('betterWebUser', JSON.stringify(userData));
            showSuccess('Account created successfully! Redirecting to setup...');
            
            setTimeout(() => {
                window.location.href = 'questionnaire.html';
            }, 1500);
        } catch (error) {
            showError('Failed to create account. Please try again.');
        }
    });
    
    // Handle login
    loginBtn.addEventListener('click', function() {
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        if (!email || !password) {
            showLoginError('Please fill in all fields.');
            return;
        }
        
        try {
            const storedUser = JSON.parse(localStorage.getItem('betterWebUser') || '{}');
            
            if (storedUser.email === email && atob(storedUser.password) === password) {
                // Check if onboarding is completed
                if (storedUser.onboardingCompleted) {
                    showLoginSuccess('Welcome back! Redirecting...');
                    setTimeout(() => {
                        window.close();
                    }, 1500);
                } else {
                    showLoginSuccess('Welcome back! Completing setup...');
                    setTimeout(() => {
                        window.location.href = 'questionnaire.html';
                    }, 1500);
                }
            } else {
                showLoginError('Invalid email or password.');
            }
        } catch (error) {
            showLoginError('Failed to sign in. Please try again.');
        }
    });
    
    // Check if user is already logged in
    checkExistingUser();
});

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showError(message) {
    const errorDiv = document.getElementById('error-message');
    const successDiv = document.getElementById('success-message');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    successDiv.style.display = 'none';
}

function showSuccess(message) {
    const errorDiv = document.getElementById('error-message');
    const successDiv = document.getElementById('success-message');
    successDiv.textContent = message;
    successDiv.style.display = 'block';
    errorDiv.style.display = 'none';
}

function showLoginError(message) {
    const errorDiv = document.getElementById('login-error-message');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function showLoginSuccess(message) {
    const errorDiv = document.getElementById('login-error-message');
    errorDiv.textContent = message;
    errorDiv.className = 'success-message';
    errorDiv.style.display = 'block';
}

function checkExistingUser() {
    try {
        const storedUser = JSON.parse(localStorage.getItem('betterWebUser') || '{}');
        if (storedUser.email && storedUser.onboardingCompleted) {
            // User exists and completed onboarding, close this window
            window.close();
        }
    } catch (error) {
        // Continue with normal flow
    }
}