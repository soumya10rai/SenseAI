// Background script for BetterWeb Extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // First install - open onboarding
    chrome.tabs.create({
      url: chrome.runtime.getURL('onboarding.html')
    });
  }
});

// Handle voice commands that require tab operations
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'VOICE_COMMAND') {
    handleVoiceCommand(message.command);
  }
  return true;
});

function handleVoiceCommand(command) {
  const lowerCommand = command.toLowerCase();
  
  // Shopping commands
  if (lowerCommand.includes('buy') && lowerCommand.includes('apollo pharmacy')) {
    const item = extractItemFromCommand(lowerCommand, 'buy', 'apollo pharmacy');
    openSearchPage('https://www.apollopharmacy.in/search-medicines/', item);
  } else if (lowerCommand.includes('amazon')) {
    const item = extractItemFromCommand(lowerCommand, '', 'amazon');
    openSearchPage('https://www.amazon.in/s?k=', item);
  } else if (lowerCommand.includes('buy') || lowerCommand.includes('show me')) {
    // Generic shopping command
    const item = extractGenericItem(lowerCommand);
    openSearchPage('https://www.google.com/search?q=buy+', item);
  }
}

function extractItemFromCommand(command, prefix, suffix) {
  let item = command;
  if (prefix) {
    item = item.replace(prefix, '').trim();
  }
  if (suffix) {
    item = item.replace(suffix, '').trim();
  }
  return item.replace(/\b(from|on|me)\b/g, '').trim();
}

function extractGenericItem(command) {
  return command
    .replace(/\b(buy|show|me|from|on)\b/g, '')
    .trim();
}

function openSearchPage(baseUrl, searchTerm) {
  const encodedTerm = encodeURIComponent(searchTerm);
  chrome.tabs.create({
    url: baseUrl + encodedTerm
  });
}