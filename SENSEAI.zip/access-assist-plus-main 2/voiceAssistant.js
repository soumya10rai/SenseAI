// AI Voice Assistant for BetterWeb Extension
class AIVoiceAssistant {
    constructor() {
        this.recognition = null;
        this.synthesis = null;
        this.isListening = false;
        this.isSpeaking = false;
        this.button = null;
        this.statusElement = null;
        this.apiKey = null;
        this.conversationHistory = [];
        this.initializeVoiceCapabilities();
        this.loadAPIKey();
    }
    
    async loadAPIKey() {
        // Try to get API key from storage
        try {
            const result = await chrome.storage.local.get(['openaiApiKey']);
            this.apiKey = result.openaiApiKey;
        } catch (error) {
            console.log('No API key found in storage');
        }
    }
    
    async saveAPIKey(apiKey) {
        try {
            await chrome.storage.local.set({ 'openaiApiKey': apiKey });
            this.apiKey = apiKey;
            this.updateUI('API key saved successfully!');
        } catch (error) {
            console.error('Failed to save API key:', error);
        }
    }
    
    initializeVoiceCapabilities() {
        // Initialize Speech Recognition
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            
            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateUI('🎤 Listening... Speak now!');
                this.button.classList.add('listening');
            };
            
            this.recognition.onresult = (event) => {
                let finalTranscript = '';
                let interimTranscript = '';
                
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }
                
                if (interimTranscript) {
                    this.updateUI(`Hearing: "${interimTranscript}"`);
                }
                
                if (finalTranscript) {
                    this.updateUI(`Processing: "${finalTranscript}"`);
                    this.processAICommand(finalTranscript);
                }
            };
            
            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.updateUI(`❌ Error: ${event.error}`);
                this.stopListening();
            };
            
            this.recognition.onend = () => {
                this.stopListening();
            };
        }
        
        // Initialize Speech Synthesis
        if ('speechSynthesis' in window) {
            this.synthesis = window.speechSynthesis;
        }
    }
    
    async startListening() {
        if (!this.recognition) {
            this.updateUI('❌ Speech recognition not supported in this browser');
            return;
        }
        
        if (!this.apiKey) {
            this.showAPIKeyPrompt();
            return;
        }
        
        try {
            // Request microphone permission
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            
            this.recognition.start();
        } catch (error) {
            console.error('Microphone permission denied:', error);
            this.updateUI('❌ Microphone permission required');
        }
    }
    
    stopListening() {
        this.isListening = false;
        this.button.classList.remove('listening');
        if (this.recognition) {
            this.recognition.stop();
        }
    }
    
    speak(text) {
        if (!this.synthesis || this.isSpeaking) return;
        
        this.isSpeaking = true;
        this.updateUI('🔊 Speaking...');
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        
        utterance.onend = () => {
            this.isSpeaking = false;
            this.updateUI('');
        };
        
        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event);
            this.isSpeaking = false;
            this.updateUI('');
        };
        
        this.synthesis.speak(utterance);
    }
    
    async processAICommand(userInput) {
        if (!this.apiKey) {
            this.updateUI('❌ OpenAI API key required');
            return;
        }
        
        try {
            this.updateUI('🤖 AI is thinking...');
            
            // Add user input to conversation history
            this.conversationHistory.push({
                role: 'user',
                content: userInput
            });
            
            // Keep conversation history manageable (last 10 messages)
            if (this.conversationHistory.length > 10) {
                this.conversationHistory = this.conversationHistory.slice(-10);
            }
            
            const systemPrompt = {
                role: 'system',
                content: `You are BetterWeb, an AI accessibility assistant for people with disabilities. You can:

1. Control accessibility features: high contrast, dark mode, font size, zoom, cursor enhancement, reading tools, focus mode, animation reduction, etc.
2. Help with web navigation and accessibility
3. Answer questions about accessibility features
4. Assist with general tasks and questions

Current available accessibility features:
- increase-font-size, increase-contrast, text-to-speech, zoom-tool, cursor-enhancer
- dark-mode, reduce-bright-colors, block-flash
- dyslexic-font, letter-spacing, line-spacing, reading-ruler
- minimal-ui, hide-distractions, reduce-animation
- And many more...

When users ask to enable features, respond conversationally and I'll handle the technical activation.
Keep responses concise but helpful. Be encouraging and supportive.`
            };
            
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: 'gpt-4.1-2025-04-14',
                    messages: [systemPrompt, ...this.conversationHistory],
                    max_tokens: 150,
                    temperature: 0.7,
                })
            });
            
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }
            
            const data = await response.json();
            const aiResponse = data.choices[0].message.content;
            
            // Add AI response to conversation history
            this.conversationHistory.push({
                role: 'assistant',
                content: aiResponse
            });
            
            // Check if the user asked for accessibility features
            this.handleAccessibilityCommands(userInput.toLowerCase());
            
            // Speak the AI response
            this.speak(aiResponse);
            this.updateUI(`🤖 ${aiResponse}`);
            
        } catch (error) {
            console.error('AI processing error:', error);
            this.updateUI('❌ AI processing failed. Check your API key.');
            
            // Fallback to basic command processing
            this.handleBasicCommands(userInput.toLowerCase());
        }
    }
    
    handleAccessibilityCommands(command) {
        const featureCommands = {
            'high contrast': 'increase-contrast',
            'contrast': 'increase-contrast',
            'font size': 'increase-font-size',
            'bigger text': 'increase-font-size',
            'larger font': 'increase-font-size',
            'dark mode': 'dark-mode',
            'zoom': 'zoom-tool',
            'magnify': 'zoom-tool',
            'cursor': 'cursor-enhancer',
            'focus mode': 'minimal-ui',
            'hide distractions': 'hide-distractions',
            'reduce animations': 'reduce-animation',
            'stop animations': 'reduce-animation',
            'reading ruler': 'reading-ruler',
            'line highlighting': 'line-highlighting',
            'text to speech': 'text-to-speech',
            'dyslexic font': 'dyslexic-font',
            'letter spacing': 'letter-spacing',
            'line spacing': 'line-spacing'
        };
        
        for (const [commandPhrase, featureId] of Object.entries(featureCommands)) {
            if (command.includes(commandPhrase)) {
                this.toggleAccessibilityFeature(featureId);
                break;
            }
        }
    }
    
    handleBasicCommands(command) {
        // Fallback responses when AI is not available
        if (command.includes('help')) {
            this.speak('I can help you with accessibility features like high contrast, dark mode, font size, and more. Just ask me to turn on any feature!');
        } else if (command.includes('hello') || command.includes('hi')) {
            this.speak('Hello! I\'m your BetterWeb accessibility assistant. How can I help you today?');
        } else {
            this.speak('I\'m here to help with accessibility. Try asking me to turn on high contrast, dark mode, or increase font size.');
        }
    }
    
    toggleAccessibilityFeature(featureId) {
        try {
            let activeFeatures = JSON.parse(localStorage.getItem('betterWebActiveFeatures') || '[]');
            
            if (activeFeatures.includes(featureId)) {
                activeFeatures = activeFeatures.filter(f => f !== featureId);
                this.sendFeatureMessage('DEACTIVATE_FEATURE', featureId);
            } else {
                activeFeatures.push(featureId);
                this.sendFeatureMessage('ACTIVATE_FEATURE', featureId);
            }
            
            localStorage.setItem('betterWebActiveFeatures', JSON.stringify(activeFeatures));
            
            // Update popup UI if visible
            const featureButton = document.querySelector(`[data-feature="${featureId}"]`);
            if (featureButton) {
                featureButton.classList.toggle('active', activeFeatures.includes(featureId));
            }
            
        } catch (error) {
            console.error('Error toggling feature:', error);
        }
    }
    
    sendFeatureMessage(action, feature) {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    type: action,
                    feature: feature
                }).catch(error => {
                    console.log('Content script not ready:', error);
                });
            }
        });
    }
    
    updateUI(message) {
        if (this.statusElement) {
            this.statusElement.innerHTML = message;
        }
        if (this.button) {
            if (this.isListening) {
                this.button.innerHTML = '🔴 Listening...';
            } else if (this.isSpeaking) {
                this.button.innerHTML = '🔊 Speaking...';
            } else {
                this.button.innerHTML = '🤖 AI Assistant';
            }
        }
    }
    
    showAPIKeyPrompt() {
        const apiKey = prompt(`To use the AI assistant, please enter your OpenAI API key:

Get your key from: https://platform.openai.com/api-keys

Your key will be stored locally and securely.`);
        
        if (apiKey && apiKey.trim()) {
            this.saveAPIKey(apiKey.trim());
        }
    }
    
    setupUI(buttonElement, statusElement) {
        this.button = buttonElement;
        this.statusElement = statusElement;
        
        // Update button text
        this.button.innerHTML = '🤖 AI Assistant';
        
        this.button.addEventListener('click', () => {
            if (this.isListening) {
                this.stopListening();
            } else if (this.isSpeaking) {
                this.synthesis.cancel();
                this.isSpeaking = false;
                this.updateUI('');
            } else {
                this.startListening();
            }
        });
        
        // Add API key management button
        const apiKeyButton = document.createElement('button');
        apiKeyButton.innerHTML = '🔑 API Key';
        apiKeyButton.className = 'feature-button';
        apiKeyButton.style.marginTop = '5px';
        apiKeyButton.style.fontSize = '11px';
        apiKeyButton.addEventListener('click', () => this.showAPIKeyPrompt());
        
        this.statusElement.parentNode.insertBefore(apiKeyButton, this.statusElement.nextSibling);
    }
}

// Initialize AI voice assistant when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const aiVoiceAssistant = new AIVoiceAssistant();
    const voiceButton = document.getElementById('voice-button');
    const voiceStatus = document.getElementById('voice-status');
    
    if (voiceButton && voiceStatus) {
        aiVoiceAssistant.setupUI(voiceButton, voiceStatus);
    }
});