# BetterWeb - Accessibility Assistant Chrome Extension

A personalized accessibility assistant for users with different disabilities. BetterWeb provides customizable features to enhance web browsing experience for people with visual, cognitive, and motor disabilities.

## Features

### 🧿 Visual Disabilities Support
- Increase Font Size
- High Contrast Mode
- Text-to-Speech
- Zoom Tool
- Cursor Size Enhancer
- Screen Reader Labels
- Colorblind Mode
- Line Highlighting
- Text Magnifier
- Reduce Animations

### 🔡 Dyslexia / Learning Disabilities
- OpenDyslexic/Clear Sans Font
- Adjust Letter Spacing
- Increase Line Spacing
- Syllable Highlighting
- Reading Ruler
- Background Tint

### 🧠 ADHD / Focus Needs
- Larger Fonts
- Minimal UI / Focus Mode
- Hide Distractions (ads/images)
- Sound Feedback
- Task Chunking UI

### 🌙 Photosensitivity
- Force Dark Mode
- Reduce Bright Colors
- Block Flash Animations

### 🧩 Neuro-Cognitive Support
- Reduce Brightness
- High Structure Layout
- Soft Color Contrast
- Fewer Animations

### 🎤 Voice Assistant
- Voice-controlled accessibility features
- Shopping commands (Apollo Pharmacy, Amazon)
- Natural language commands for settings

## Installation

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The extension will appear in your toolbar

## First Time Setup

1. When first installed, BetterWeb opens an onboarding page
2. Create an account or sign in
3. Complete the accessibility questionnaire
4. Select features that match your needs
5. Start browsing with your personalized accessibility assistant!

## Usage

### Popup Interface
- Click the BetterWeb icon in your toolbar
- Toggle accessibility features on/off
- Access voice assistant
- Export/import settings

### Voice Commands
Click the microphone button and try:
- "Turn on high contrast mode"
- "Increase font size"
- "Enable dark mode"
- "Buy paracetamol from Apollo Pharmacy"
- "Show me laptops on Amazon"

### Content Script Features
All accessibility features automatically apply to web pages you visit, based on your preferences.

## Technical Details

- **Manifest V3** compatible
- **Vanilla JavaScript** (no frameworks)
- **Local Storage** for preferences
- **Web Speech API** for voice commands
- **Content Scripts** for page modifications
- **Cross-site compatibility**

## File Structure

```
chrome-extension/
├── manifest.json          # Extension manifest
├── background.js          # Background service worker
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
├── style.css             # Global styles
├── onboarding.html       # First-time setup page
├── onboarding.js         # Onboarding logic
├── questionnaire.html    # Accessibility preferences setup
├── questionnaire.js      # Questionnaire functionality
├── voiceAssistant.js     # Voice command processing
├── content.js            # Page modification scripts
├── content.css           # Content styling
├── icons/                # Extension icons
└── README.md            # This file
```

## Privacy & Data

- All data stored locally in browser
- No external servers or data collection
- Voice commands processed locally
- Settings can be exported/imported

## Customization

Users can:
- Enable/disable specific features
- Reconfigure accessibility preferences
- Export settings for backup
- Reset all settings
- Adjust feature intensity

## Browser Compatibility

- Chrome (Manifest V3)
- Chromium-based browsers
- Requires microphone permission for voice features

## Contributing

This extension is designed to be easily extensible. To add new accessibility features:

1. Add feature definition in `questionnaire.html`
2. Implement feature logic in `content.js`
3. Add corresponding CSS in `content.css`
4. Update popup interface in `popup.js`

## License

Open source - feel free to modify and distribute.

## Support

For issues or feature requests, please check the browser console for error messages and ensure all permissions are granted.