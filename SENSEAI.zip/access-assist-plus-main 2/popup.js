// Popup script for BetterWeb Extension
document.addEventListener('DOMContentLoaded', function() {
    loadUserPreferences();
    setupEventListeners();
});

function loadUserPreferences() {
    try {
        const preferences = JSON.parse(localStorage.getItem('betterWebPreferences') || '{}');
        const selectedFeatures = JSON.parse(localStorage.getItem('betterWebSelectedFeatures') || '[]');
        
        // Hide loading message
        document.getElementById('loading-message').style.display = 'none';
        
        if (selectedFeatures.length === 0) {
            document.getElementById('no-features-message').style.display = 'block';
            return;
        }
        
        // Show features container
        document.getElementById('features-container').style.display = 'block';
        
        // Feature definitions with user-friendly names
        const featureDefinitions = {
            // Visual Features
            'increase-font-size': { name: 'Increase Font Size', category: 'visual' },
            'increase-contrast': { name: 'High Contrast Mode', category: 'visual' },
            'text-to-speech': { name: 'Text-to-Speech', category: 'visual' },
            'zoom-tool': { name: 'Page Zoom', category: 'visual' },
            'cursor-enhancer': { name: 'Large Cursor', category: 'visual' },
            'screen-reader-labels': { name: 'Screen Reader Labels', category: 'visual' },
            'colorblind-mode': { name: 'Colorblind Friendly', category: 'visual' },
            'line-highlighting': { name: 'Line Highlighting', category: 'visual' },
            'text-magnifier': { name: 'Text Magnifier', category: 'visual' },
            'reduce-animation': { name: 'Reduce Animations', category: 'visual' },
            
            // Dyslexia Features
            'dyslexic-font': { name: 'Dyslexic Font', category: 'dyslexia' },
            'letter-spacing': { name: 'Letter Spacing', category: 'dyslexia' },
            'line-spacing': { name: 'Line Spacing', category: 'dyslexia' },
            'syllable-highlighting': { name: 'Syllable Highlighting', category: 'dyslexia' },
            'reading-ruler': { name: 'Reading Ruler', category: 'dyslexia' },
            'background-tint': { name: 'Background Tint', category: 'dyslexia' },
            
            // ADHD Features
            'larger-fonts': { name: 'Extra Large Fonts', category: 'adhd' },
            'minimal-ui': { name: 'Focus Mode', category: 'adhd' },
            'hide-distractions': { name: 'Hide Distractions', category: 'adhd' },
            'sound-feedback': { name: 'Sound Feedback', category: 'adhd' },
            'task-chunking': { name: 'Task Chunking', category: 'adhd' },
            
            // Photosensitivity Features
            'dark-mode': { name: 'Force Dark Mode', category: 'photosensitivity' },
            'reduce-bright-colors': { name: 'Dim Bright Colors', category: 'photosensitivity' },
            'block-flash': { name: 'Block Flash Content', category: 'photosensitivity' },
            
            // Neuro-Cognitive Features
            'reduce-brightness': { name: 'Reduce Brightness', category: 'neurocognitive' },
            'high-structure': { name: 'Structured Layout', category: 'neurocognitive' },
            'soft-contrast': { name: 'Soft Contrast', category: 'neurocognitive' },
            'fewer-animations': { name: 'Minimal Animations', category: 'neurocognitive' }
        };
        
        // Group features by category and render
        const categorizedFeatures = {
            visual: [],
            dyslexia: [],
            adhd: [],
            photosensitivity: [],
            neurocognitive: []
        };
        
        selectedFeatures.forEach(feature => {
            const definition = featureDefinitions[feature];
            if (definition) {
                categorizedFeatures[definition.category].push({
                    id: feature,
                    name: definition.name
                });
            }
        });
        
        // Render each category
        Object.keys(categorizedFeatures).forEach(category => {
            const features = categorizedFeatures[category];
            if (features.length > 0) {
                const sectionElement = document.getElementById(`${category}-section`);
                const featuresContainer = document.getElementById(`${category}-features`);
                
                if (sectionElement && featuresContainer) {
                    sectionElement.style.display = 'block';
                    
                    features.forEach(feature => {
                        const button = createFeatureButton(feature.id, feature.name);
                        featuresContainer.appendChild(button);
                    });
                }
            }
        });
        
    } catch (error) {
        console.error('Error loading preferences:', error);
        document.getElementById('loading-message').textContent = 'Error loading preferences';
    }
}

function createFeatureButton(featureId, featureName) {
    const button = document.createElement('button');
    button.className = 'feature-button';
    button.textContent = featureName;
    button.dataset.feature = featureId;
    
    // Check if feature is currently active
    const isActive = isFeatureActive(featureId);
    if (isActive) {
        button.classList.add('active');
    }
    
    button.addEventListener('click', function() {
        toggleFeature(featureId, button);
    });
    
    return button;
}

function isFeatureActive(featureId) {
    try {
        const activeFeatures = JSON.parse(localStorage.getItem('betterWebActiveFeatures') || '[]');
        return activeFeatures.includes(featureId);
    } catch (error) {
        return false;
    }
}

function toggleFeature(featureId, buttonElement) {
    try {
        let activeFeatures = JSON.parse(localStorage.getItem('betterWebActiveFeatures') || '[]');
        
        if (activeFeatures.includes(featureId)) {
            // Deactivate feature
            activeFeatures = activeFeatures.filter(f => f !== featureId);
            buttonElement.classList.remove('active');
            sendMessageToContentScript('DEACTIVATE_FEATURE', featureId);
        } else {
            // Activate feature
            activeFeatures.push(featureId);
            buttonElement.classList.add('active');
            sendMessageToContentScript('ACTIVATE_FEATURE', featureId);
        }
        
        localStorage.setItem('betterWebActiveFeatures', JSON.stringify(activeFeatures));
        
    } catch (error) {
        console.error('Error toggling feature:', error);
    }
}

function sendMessageToContentScript(action, feature) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
                type: action,
                feature: feature
            }).catch(error => {
                // Content script might not be loaded yet
                console.log('Content script not ready:', error);
            });
        }
    });
}

function setupEventListeners() {
    // Setup link
    const setupLink = document.getElementById('setup-link');
    if (setupLink) {
        setupLink.addEventListener('click', function(e) {
            e.preventDefault();
            chrome.tabs.create({
                url: chrome.runtime.getURL('questionnaire.html')
            });
        });
    }
    
    // Reconfigure link
    const reconfigureLink = document.getElementById('reconfigure-link');
    if (reconfigureLink) {
        reconfigureLink.addEventListener('click', function(e) {
            e.preventDefault();
            chrome.tabs.create({
                url: chrome.runtime.getURL('questionnaire.html')
            });
        });
    }
    
    // Reset all button
    const resetBtn = document.getElementById('reset-all');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to reset all accessibility settings?')) {
                localStorage.removeItem('betterWebActiveFeatures');
                
                // Deactivate all features on current page
                chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                    if (tabs[0]) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            type: 'RESET_ALL_FEATURES'
                        }).catch(error => {
                            console.log('Content script not ready:', error);
                        });
                    }
                });
                
                // Update UI
                const activeButtons = document.querySelectorAll('.feature-button.active');
                activeButtons.forEach(button => button.classList.remove('active'));
            }
        });
    }
    
    // Export settings button
    const exportBtn = document.getElementById('export-settings');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            try {
                const preferences = localStorage.getItem('betterWebPreferences');
                const activeFeatures = localStorage.getItem('betterWebActiveFeatures');
                const userData = localStorage.getItem('betterWebUser');
                
                const exportData = {
                    preferences: JSON.parse(preferences || '{}'),
                    activeFeatures: JSON.parse(activeFeatures || '[]'),
                    userData: JSON.parse(userData || '{}'),
                    exportedAt: new Date().toISOString()
                };
                
                const dataStr = JSON.stringify(exportData, null, 2);
                const dataBlob = new Blob([dataStr], { type: 'application/json' });
                const url = URL.createObjectURL(dataBlob);
                
                const link = document.createElement('a');
                link.href = url;
                link.download = 'betterweb-settings.json';
                link.click();
                
                URL.revokeObjectURL(url);
            } catch (error) {
                alert('Failed to export settings');
            }
        });
    }
}